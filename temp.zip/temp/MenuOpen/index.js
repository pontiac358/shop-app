import React from 'react';
import Products from '../../src/containers/Products/index'

class MenuOpen extends React.Component {
    componentWill

    render() {
        return (
            <Products/>
        );
    }
}
export default MenuOpen;